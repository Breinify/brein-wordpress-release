<?php

/*
 * See https://codex.wordpress.org/Function_Reference/register_uninstall_hook#uninstall.php
 * for further information regarding the uninstall.php. As the article quotes, it is
 * emphasis to use the uninstall.php instead of the uninstall hook, i.e.,
 * "Emphasis is put on using the 'uninstall.php' way of uninstalling the plugin rather than
 * register_uninstall_hook."
 */
if (!defined('ABSPATH') || !defined('WP_UNINSTALL_PLUGIN')) {
    exit();
}

// TODO: we have to modify the uninstall, so that it'll work
$option_name = 'plugin_option_name';

delete_option($option_name);
delete_site_option($option_name);

//drop a custom db table
global $wpdb;
$wpdb->query('DROP TABLE IF EXISTS {$wpdb->prefix}mytable');