<?php
if (!defined('ABSPATH')) {
    exit;
}
?>

<div style="text-align:center">ERROR</div>